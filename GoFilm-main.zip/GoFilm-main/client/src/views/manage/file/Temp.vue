<template>
<div>
  <h2 style="color: #8e48b4">功能开发中, 请关注后续更新</h2>
</div>
</template>



<script setup lang="ts">

</script>



<style scoped>

</style>