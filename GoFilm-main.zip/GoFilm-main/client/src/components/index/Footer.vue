<template>
    <div class="custom-footer">
        本站所有内容均来自互联网分享站点所提供的公开引用资源，未提供资源上传、存储服务。
    </div>
</template>

<script lang="ts" setup>


</script>

<style scoped>
.custom-footer {
    text-align: center;
    width: 100%;
    height: 30px;
    text-align: center;
    line-height: 15px;
    font-size: 15px;
    color: #888888;
    margin-top: 25px;
}
</style>